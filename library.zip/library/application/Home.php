<?php
class Home extends CI_Controller
{
   function index()
  {
    echo 'this is a Home controller';
  }

}
?>

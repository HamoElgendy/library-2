<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class genre_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }
  function addgenre(){
  $data = array(
    'genrename' => $this->input->post("genrename")
  );
  $this->db->insert('genre', $data);
  return true;
  }


}

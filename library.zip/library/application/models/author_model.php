<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class author_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }
  function addauthor(){
  $data = array(
    'authorname' => $this->input->post("authorname")
  );
  $this->db->insert('author', $data);
  return true;
  }
  function getauthor() {
      $sql = "select * from author";
      $query = $this->db->query($sql);
      $results = array();
      foreach ($query->result() as $result) {
        $results[] = $result;
      }
      return $results;
    }
    function gettype() {
        $sql = "select * from type";
        $query = $this->db->query($sql);
        $results = array();
        foreach ($query->result() as $result) {
          $results[] = $result;
        }
        return $results;
}
}

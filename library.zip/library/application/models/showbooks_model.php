<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class showbooks_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }

  function get_all_books()
   {
     $sql = "SELECT books.idbooks, books.bookname, books.ISNBnumber,books.publishingdate,multipleeditions.edithionnumber,multipleeditions.printsdate,
     books.numberofpages, books.bestofcollections,books.numberofbooks, author.authorname
     ,genre.genrename,type.typename
  FROM ((((((books_has_author INNER JOIN books on books_has_author.books_idbooks= books.idbooks)
 INNER JOIN author ON books_has_author.author_idauthor=author.idauthor)
 INNER JOIN books_has_type ON  books.idbooks= books_has_type.books_idbooks)
 INNER JOIN type ON  books_has_type.type_idtype=type.idtype)
 INNER JOIN books_has_genre ON books. idbooks= books_has_genre.books_idbooks)
 INNER JOIN genre ON books_has_genre.genre_genreid=genre.genreid)
 inner join multipleeditions on books.idbooks=multipleeditions.books_idbooks";
   $query = $this->db->query($sql);
   $results = array();
   foreach ($query->result() as $x) {
     $results[] = $x;
   }
   return $results;
 }


}

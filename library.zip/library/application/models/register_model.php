<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class register_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }
function register(){
$data = array(
  'username' => $this->input->post("username"),
  'firstname' => $this->input->post("firstname"),
  'lastname' => $this->input->post("lastname"),
  'password' => $this->input->post("password"),
  'email' => $this->input->post("email"),
);
$this->db->insert('login', $data);
return true;
}

}

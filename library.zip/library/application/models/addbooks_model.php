<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class addbooks_model extends CI_Model {

  function __construct() {
    parent::__construct();
  }


  function theaddbooks() {
  $data = array(
          'bookname' => $this->input->post("bookname"),
          'ISNBnumber' => $this->input->post("ISNBnumber"),
          'publishingdate' => $this->input->post("publishingdate"),
          'numberofpages' => $this->input->post("numberofpages"),
          'bestofcollections' => $this->input->post("bestofcollections"),
          'numberofbooks' => $this->input->post("numberofbooks")
  );
  $this->db->insert('books', $data);

  $lastidbooks = $this->db->insert_id();

  $editionnumber = $this->input->post("edithionnumber");
  $printdate = $this->input->post("printsdate");
  $bookid = $lastidbooks;

  $sql = "insert into multipleeditions (edithionnumber, printsdate, books_idbooks) values ($editionnumber, '$printdate', $bookid)";
  $query = $this->db->query($sql);

  $authors = $this->input->post("author");
  foreach($authors as $author)
  {
    $data = array(
            'books_idbooks' => $lastidbooks,
            'author_idauthor' => $author,
    );
    $this->db->insert('books_has_author', $data);
  }

  $genres = $this->input->post("genre");
  foreach($genres as $genre)
  {
    $data = array(
            'books_idbooks' => $lastidbooks,
            'genre_genreid' => $genre,
    );
    $this->db->insert('books_has_genre', $data);
  }

  $types = $this->input->post("type");
  foreach($types as $type)
  {
    $data = array(
            'books_idbooks' => $lastidbooks,
            'type_idtype' => $type,
    );
    $this->db->insert('books_has_type', $data);
  }

  return 1 ;
}

  function getauthor() {
      $sql = "select * from author";
      $query = $this->db->query($sql);
      $results = array();
      foreach ($query->result() as $result) {
        $results[] = $result;
      }
      return $results;
    }
    function gettype() {
        $sql = "select * from type";
        $query = $this->db->query($sql);
        $results = array();
        foreach ($query->result() as $result) {
          $results[] = $result;
        }
        return $results;
}
function getgenre() {
    $sql = "select * from genre";
    $query = $this->db->query($sql);
    $results = array();
    foreach ($query->result() as $result) {
      $results[] = $result;
    }
    return $results;
  }
  function getbooksDetailsbyID($id)
  {
    $sql = "select * from books inner join multipleeditions on books.idbooks=multipleeditions.books_idbooks where idbooks=$id";
    $query = $this->db->query($sql);
    return $query->result();
  }
  function getbooks_has_authorbyID($id)
  {
    $sql = "select * from books_has_author where books_idbooks=$id";
    $query = $this->db->query($sql);
    $results = array();
    foreach ($query->result() as $result) {
      $results[] = $result;
    }
    return $results;
  }
  function getbooks_has_genrebyID($id)
  {
    $sql = "select * from books_has_genre where books_idbooks=$id";
    $query = $this->db->query($sql);
    $results = array();
    foreach ($query->result() as $result) {
      $results[] = $result;
    }
    return $results;
  }
  function getbooks_has_typebyID($id)
  {
    $sql = "select * from books_has_type where books_idbooks=$id";
    $query = $this->db->query($sql);
    $results = array();
    foreach ($query->result() as $result) {
      $results[] = $result;
    }
    return $results;
  }

  function updatebook() {
	    $id = $this->input->post("idbooks");
	    $bookname = $this->input->post("bookname");
			$ISNBnumber = $this->input->post("ISNBnumber");
	    $publishingdate = $this->input->post("publishingdate");
    	$numberofpages = $this->input->post("numberofpages");
    	$bestofcollections = $this->input->post("bestofcollections");
      $numberofbooks = $this->input->post("numberofbooks");

	    $sql = "update books
	    set bookName='$bookname',
	    ISNBnumber=$ISNBnumber,
	    publishingdate='$publishingdate',
      numberofpages=$numberofpages,
    	bestofcollections='$bestofcollections',
    	numberofbooks=$numberofbooks
	    where idbooks=$id";
	    $query = $this->db->query($sql);


      $editionnumber = $this->input->post("edithionnumber");
      $printsdate = $this->input->post("printsdate");

      $sql = "update multipleeditions
      set edithionnumber=$editionnumber,
      printsdate=$printsdate
      where books_idbooks=$id";
      $query = $this->db->query($sql);





	    $sql = "delete from books_has_author where books_idbooks = $id";
	    $query = $this->db->query($sql);

	    $author = $this->input->post("author");
	    if(!isset($author))
	    {
	      return 1;
	    }
	    foreach($author as $author)
	    {
	      $data = array(
	              'books_idbooks' => $id,
	              'author_idauthor' => $author,
	      );
	      $this->db->insert('books_has_author', $data);
	    }

      $sql = "delete from books_has_genre where books_idbooks = $id";
      $query = $this->db->query($sql);

      $genre = $this->input->post("genre");
      if(!isset($genre))
      {
        return 1;
      }
      foreach($genre as $genre)
      {
        $data = array(
                'books_idbooks' => $id,
                'genre_genreid' => $genre,
        );
        $this->db->insert('books_has_genre', $data);
      }

      $sql = "delete from books_has_type where books_idbooks = $id";
      $query = $this->db->query($sql);

      $type = $this->input->post("type");
      if(!isset($type))
      {
        return 1;
      }
      foreach($type as $type)
      {
        $data = array(
                'books_idbooks' => $id,
                'type_idtype' => $type,
        );
        $this->db->insert('books_has_type', $data);
      }

      return 1;
	  }
    function thedelete($id)
    {
      $sql = "delete from books where idbooks = $id";
      $query = $this->db->query($sql);
      return  1;
    }
}

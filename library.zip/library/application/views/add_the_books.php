<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>the library</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>style.css">	<meta charset="utf-8">
<script type="text/javascript">
	   <!--
	      // Form validation code will come here.
	      function validateForm()
	      {

	         if( document.forms["updatebooks"]["bookname"].value == "" )
	         {
	            alert( "Please provide student bookname!" );
	            return false;
	         }

	         if( document.forms["updatebooks"]["ISNBnumber"].value == "" )
	         {
	            alert( "Please provide ISNB Number!" );
	            return false;
	         }
					 if( document.forms["updatebooks"]["publishingdate"].value == "" )
					{
						 alert( "Please provide publishing Date!" );
						 return false;
					}
					if( document.forms["updatebooks"]["multipleeditions"].value == "" )
					{
						 alert( "Please provide multiple Editions!" );
						 return false;
					}
					if( document.forms["updatebooks"]["numberofpages"].value == "" )
					{
						 alert( "Please provide number of pages!" );
						 return false;
					}
					if( document.forms["updatebooks"]["bestofcollections"].value == "" )
					{
						 alert( "Please provide best of collections!" );
						 return false;
					}
					if( document.forms["updatebooks"]["numberofbooks"].value == "" )
					{
						 alert( "Please provide number of books!" );
						 return false;
					}

	      }
	   //-->
	</script>
<style media="screen">
body{
	background: url('https://www.bookprintingcompany.com.au/images/book_sizes.jpg') no-repeat center center fixed;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size: cover;
	background-size: cover;
}
</style>
<style>

	.btn {
    background-color: DodgerBlue;
    border: 2px solid white;
    color: white;
    padding: 5px 15px;
    font-size: 16px;
    cursor: pointer;
		float: right;
}

/* Darker background on mouse-over */
.btn:hover {
    background-color: RoyalBlue;
}
input[type=text] {
		width: 100%;
		padding: 12px 20px;
		margin: 8px 0;
		box-sizing: border-box;
}
input[type=text], input[type=password] {
	width: 100%;
	padding: 15px;
	margin: 5px 0 22px 0;
	display: inline-block;
	border: none;
	background: #f1f1f1;
}
.Addbtn {
		background-color: #4CAF50;
		color: white;
		padding: 16px 20px;
		margin: 8px 0;
		border: none;
		cursor: pointer;
		width: 100%;
		opacity: 0.9;
}

.Addbtn:hover {
		opacity: 1;
}
</style>

</head>
<body>
<h1 style=text-align:center>The Add </h1>
	<form name="addbooks" action="<?php echo base_url(); ?>index.php/library/addbooksresult" onsubmit="return validateForm()" method="post">
		 book Name: <input type="text" name="bookname" required><br>
		 ISNB Number: <input type="text" name="ISNBnumber"required><br>
	 Publishing date: <input type="date" name=" publishingdate"required><br><br>
			edition number : <input type="text" name="edithionnumber"required><br>
			printsdate  : <input type="date" name="printsdate"required><br>

		 Number of pages  : <input type="text" name="numberofpages"required><br>
		Best of collections : <input type="text" name="bestofcollections"required><br>
		Number of books : <input type="text" name="numberofbooks"required><br>


			 <?php
    echo "Authors<br>";
		foreach ($authorlist as $author)
		{
			echo '<input type="checkbox" name="author[]" value="'.$author->idauthor.'"> '.$author->authorname.'<br>';
		}



		echo '<br><br> genre <br>';

		foreach ($genrelist as $genre)
		{
			echo '<input type="checkbox" name="genre[]" value="'.$genre->genreid.'"> '.$genre->genrename.'<br>';
		}

		echo '<br><br> type <br>';

		foreach ($typelist as $type)
		{
			echo '<input type="checkbox" name="type[]" value="'.$type->idtype.'"> '.$type->typename.'<br>';
		}
  echo' <button type="submit" class="Addbtn">Add</button>
	</from>';

	?>




</body>
</html>

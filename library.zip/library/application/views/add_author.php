<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style media="screen">
  body{
    background: url('https://www.barbican.org.uk/sites/default/files/styles/hero_constrained_small/public/images/2018-06/IMG_6492.JPG?itok=oc48m2AZ') no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
  }
  </style>

	<title>the library</title>
  <style>
  input[type=text] {
      width: 50%;
      padding: 12px 20px;
      margin: 8px 0;
      box-sizing: border-box;
  }
  input[type=text], {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

  .addbtn {
      background-color: #2980B9 ;
      color: white;
      padding: 16px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 10%;
      opacity: 0.9;
  }

  .addbtn:hover {
      opacity: 1;
  }



  </style>

</head>
<body>
<div><h1>Add author</h1></div>
<?php
if(isset($result))
{
	echo "author added";
}
else {

echo '<form name="addauthor" action="'.base_url().'index.php/library/addauthor" onesubmit="return validateForm()" method="post">
  <label for="authorname"><b>Author Name</b></label>
  <input type="text" placeholder="Enter Author Name" id="authorname" name="authorname">';
	echo '</select>
  <br> <button type="submit" class="addbtn">Add</button><br>
 	</form>';

}
?>






</body>
</html>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>the library</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>style.css">	<meta charset="utf-8">
<style media="screen">
body{
	background: url('https://www.bookprintingcompany.com.au/images/book_sizes.jpg') no-repeat center center fixed;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size: cover;
	background-size: cover;
}
</style>
</style>

<title>the library</title>
<style>
input[type=text] {
		width: 50%;
		padding: 12px 20px;
		margin: 8px 0;
		box-sizing: border-box;
}
input[type=text], {
	width: 100%;
	padding: 15px;
	margin: 5px 0 22px 0;
	display: inline-block;
	border: none;
	background: #f1f1f1;
}

.addbtn {
		background-color: #2980B9 ;
		color: white;
		padding: 16px 20px;
		margin: 8px 0;
		border: none;
		cursor: pointer;
		width: 10%;
		opacity: 0.9;
}

.addbtn:hover {
		opacity: 1;
}



</style>

</head>
<body>
<h1 style="text-align:center">show the books</h1>
<form name="books" action="<?php echo base_url(); ?>index.php/library/thesearch" method="post">
 Book Name: <input type="text" name="bookname"required><br>

 <br> <button type="submit" class="addbtn">submit</button><br>

</form>
<?php
if(isset($books))
 {
	 if(count($books) == 0)
	 {
		 echo "no results found";
	 }
	 else {
		echo '<div><h1>books result</h1></div>
		<div class="divTable">
		<div class="divTableHeading">
		<div class="divTableRow">
		<div class="divTableHead">bookname</div>
	 <div class="divTableHead">ISNBnumber</div>
	 <div class="divTableHead">publishingdate</div>
		<div class="divTableHead">multipleeditions</div>
		<div class="divTableHead">pranitdate</div>
		<div class="divTableHead">authorname</div>
		<div class="divTableHead">genrename</div>
		<div class="divTableHead">typename</div>
		<div class="divTableHead">numberofpages</div>
		<div class="divTableHead">bestofcollections</div>
		<div class="divTableHead">numberofbooks</div>
		<div class="divTableHead">Edit</div>
		<div class="divTableHead">Delete</div>


		</div>
		</div>
		<div class="divTableBody">';


					foreach ($books as $book) {

						echo '<div class="divTableRow">';
						echo '<div class="divTableCell">'.$book->bookname.'</div>';
					 echo '<div class="divTableCell">'.$book->ISNBnumber.'</div>';
					 echo '<div class="divTableCell">'.$book->publishingdate.'</div>';
					 echo '<div class="divTableCell">'.$book->edithionnumber.'</div>';
					 echo '<div class="divTableCell">'.$book->printsdate.'</div>';

					 echo '<div class="divTableCell">'.$book->authorname.'</div>';
						echo '<div class="divTableCell">'.$book->genrename.'</div>';
						echo '<div class="divTableCell">'.$book->typename.'</div>';
						echo '<div class="divTableCell">'.$book->numberofpages.'</div>';
						echo '<div class="divTableCell">'.$book->bestofcollections.'</div>';
						echo '<div class="divTableCell">'.$book->numberofbooks.'</div>';
						echo '<div class="divTableCell"><a href="'. base_url().'index.php/library/editbooks/'.$book->idbooks.'">edit</a></div>';
						echo '<div class="divTableCell"><a href="'. base_url().'index.php/library/delete_book/'.$book->idbooks.'">delete</a></div>';


						echo '</div>';
					}
			echo"</div></div>";
	 }

	}
 ?>




</body>
</html>

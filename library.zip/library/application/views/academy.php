<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Academy extends CI_Controller {
/**
 * constructer for Academy controller. we load the models here
 */
	public function __construct() {
    parent::__construct();

    $this->load->model('student_model');
		$this->load->model('academy_model');
		$this->load->helper('url');

  }
/**
 * Index loads the defalut view when you go to http://localhost:8888/academy/
 * @return null no return expcted
 */
	public function index()
	{
		$this->load->view('login');
	}
/**
 * action to the login form in http://localhost:8888/academy/
 * here we check if we have a correct username and password.
 * if we do, we create a session with keys isuserloggedin & userrole and redicrect to http://localhost:8888/academy/index.php/Academy/mainpage
 * if not, we disply a "wrong username and password message"
 * @return null no return expcted
 */
	public function loginrequest()
	{
		//call academy_model.login(username,password)
		//pass the values from the form via post
		$result = $this->academy_model->login($this->input->post("username"),$this->input->post("userpassword"));
		//if the result is not zero (if there is a record with the inputted username and password)
		if($result!=0)
		{
			//create session, to make sure a user can't access any page without logging in
			$this->session->set_userdata('isuserloggedin', 'true');
			//store the user role for future use (redirecting to different parts of the app)
			$this->session->set_userdata('userrole', $result);
			//go to the home page
			redirect('/Academy/mainpage');
		}
		else
		{
			//disply an error to the user
			echo "wrong username or password";
		}
	}

	/**
	 * mainpage loads http://localhost:8888/academy/index.php/Academy/mainpage
	 * called if login is Successful.
	 * @return null no return expcted
	 */
	public function mainpage()
	{
		$this->load->view('academy_main');
	}
	/**
	 * showallstudents is called when you go to url http://localhost:8888/academy/index.php/Academy/showallstudents
	 * it calls student_model.get_all_students() to show all students
	 * @return null no return expcted
	 */
	public function showallstudents()
	{
		//call student_model.get_all_students(studentName) to get all students
		$all_students = $this->student_model->get_all_students();
		//create an empty array called data
    $data = array();
		//add the results from the model which are stored in $all_students to data and give it key "students"
		//we'll use this key to access the data in the view
    $data['students'] = $all_students;
		//load view show_students.php and pass to it the array data
		$this->load->view('show_students',$data);
	}
	/**
	 * this function to load the view http://localhost:8888/academy/index.php/academy/search_student_by_name
	 * the function checks if there is a post from the from in the view.
	 * if there is, then it calls the model student_model.searchStudentByName(studentName) and sends the results to the page to display them
	 * if there isn't it loads the page with the empty form
	 * @return null no return expcted
	 */
	public function search_student_by_name()
	{
		//if the form was submitted and the student name feild was posted
		if($this->input->post("studentName"))
		{
			// call student_model.searchStudentByName(studentName) to get search results
			$result = $this->student_model->searchStudentByName($this->input->post("studentName"));

			//create an empty array called data
			$data = array();

			//add the results from the model which are stored in $result to data and give it key "student"
			//we'll use this key to access the data in the view
	    $data['student'] = $result;

			//load view search_student_by_name.php and pass to it the array data
			$this->load->view('search_student_by_name',$data);
		}
		else
		{
			//load view search_student_by_name.php and no data passed
			$this->load->view('search_student_by_name');
		}

	}
	/**
	 * add_student is called when you go to this url http://localhost:8888/academy/index.php/academy/add_student
	 * to load this view we need to get majors and get hobbies from the Database
	 * we use student_model.getMajors() & student_model.getHobbies() to get the lists
	 */
	public function add_student()
	{
		// call student_model.getMajors() to get list of all the majors
		$result = $this->student_model->getMajors();

		//create an empty array called data
		$data = array();

		//add the results from the model which are stored in $result to data and give it key "majorList"
		//we'll use this key to access the data in the view
		$data['majorList'] = $result;

		// call student_model.getHobbies() to get list of all the hobbies
		$result = $this->student_model->getHobbies();

		//add the results from the model which are stored in $result to data and give it key "hobbyList"
		//we'll use this key to access the data in the view
		$data['hobbyList'] = $result;

		//load view add_student.php and pass the data array
		$this->load->view('add_student',$data);
	}

	/**
	 * add_student_result is the action from the from in http://localhost:8888/academy/index.php/academy/add_student
	 * we call student_model.addStudent() function to insert the new student to the database
	 */
	public function add_student_result()
	{
			$this->student_model->addStudent();
			$this->load->view('add_student_result');
	}

	/**
	 * editStudent is called when you click on the edit button in showallstudents page. the link to show this function is http://localhost:8888/academy/index.php/academy/editStudent/1
	 * in the link editStudent/1 .. editStudent is the function & 1 is the id of the user we'll be editing.
	 * in editUser we prepare all the required data to autofill the form with the current user details
	 * @param  Integer $id user id we wish to edit
	 * @return null     no return expected
	 */
	public function editStudent($id)
	{

		// call student_model.getMajors() to get list of all the majors
		$result = $this->student_model->getMajors();

		//create an empty array called data
		$data = array();

		//add the results from the model which are stored in $result to data and give it key "majorList"
		//we'll use this key to access the data in the view
		$data['majorList'] = $result;

		// call student_model.getHobbies() to get list of all the hobbies
		$result = $this->student_model->getHobbies();

		//add the results from the model which are stored in $result to data and give it key "hobbyList"
		//we'll use this key to access the data in the view
		$data['hobbyList'] = $result;

		// call student_model.getStudentDetailsbyID(id) to get student details via their ID
		$result = $this->student_model->getStudentDetailsbyID($id);

		//add the results from the model which are stored in $result to data and give it key "student"
		//we'll use this key to access the data in the view
		$data['student'] = array_pop($result);

		// call student_model.getStudentHobbiesbyID(id) to get the student hobbies iva their ID
		$result = $this->student_model->getStudentHobbiesbyID($id);

		//add the results from the model which are stored in $result to data and give it key "studentHobbies"
		//we'll use this key to access the data in the view
		$data['studentHobbies'] = $result;

		//load view editStudent.php and pass the data array
		$this->load->view('editStudent',$data);
	}
	/**
	 * the action from the form in http://localhost:8888/academy/index.php/academy/editStudent/1
	 * updateStudent will take the data from the form and updates the student based on their ID
	 * @return null no return expected
	 */
	public function updateStudent()
	{
			$this->student_model->updateStudent();
			$this->load->view('update_student_result');
	}

	/**
	 * logout delets the user session, forcing them to login again before they can use the system
	 * @return null no return exptected
	 */
	public function logout()
	{
		$this->session->unset_userdata('isuserloggedin');
		$this->session->unset_userdata('userrole');
		redirect('/Academy');
	}
}

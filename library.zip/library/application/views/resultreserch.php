
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
isset($_SESSION['isuserloggedin']) OR exit('please login');

$this->load->helper('url');

?><!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>style.css">	<meta charset="utf-8">
	<title>search books</title>


</head>
<body><h1>The Search  </h1>
	<form action="<?php echo base_url(); ?>index.php/library/theresult" method="post">
    <input type="text" placeholder="Search for books,e-books,DVD,CD,more.." name="search">
    <button type="submit"><i class="fa fa-search"></i></button>




		 </form>
   </body>
 </html>

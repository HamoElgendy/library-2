<?php
defined('BASEPATH') OR exit('No direct script access allowed');
isset($_SESSION['isuserloggedin']) OR exit('please login');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>the library</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style media="screen">
	body{
		background: url('https://www.helperhelper.com/wp-content/uploads/2015/10/bigstock-Stack-Of-Books-70033240.jpg') no-repeat center center fixed;
		-webkit-background-size: cover;
		-moz-background-size: cover;
		-o-background-size: cover;
		background-size: cover;
	}
	</style>
	<style>

	button {
      background-color: #008080;
      color: #white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 10%;
			float: right;

  }

	* {
	  box-sizing: border-box;
	}
	.menu {
	  float: left;
	  width: 20%;
		font-size: 15pt;


	}
	.menuitem {
	  padding: 8px;
	  margin-top: 7px;
	  border-bottom: 1px solid #000000;
	}
	.main {
	  float: left;
	  width: 80%;
	  padding: 0 20px;
	  overflow: hidden;
		color: #fff
	}
	.right {
	  background-color: blue;
	  float: left;
	  width: 20%;
	  padding: 10px 15px;
	  margin-top: 7px;
	}

	}
	</style>

</head>
<body>

<div><h1 style="text-align:center; color: #fff	;font-size: 3vw "> welcome to Local Municipality Library </h1></div>
<body style="font-family:Verdana;">

<div style="padding:5px;">
	<div style="color: #fff ;font-size: 2vw; " >
  <h3>the list</h3>
</div>
</div>

<div style="overflow:auto">
  <div class="menu">

    <div class="menuitem"><a href="<?php echo base_url();?>index.php/library/register"><div style="color: #fff;">Register</div></a><br></div>
    <div class="menuitem"><a href="<?php echo base_url();?>index.php/library/thesearch"><div style="color: #fff;">Search the books by name</div></a></div>
    <div class="menuitem"><a href="<?php echo base_url();?>index.php/library/showallbooks"><div style="color: #fff;">Show the books</div></a></div>
		<div class="menuitem"><a href="<?php echo base_url();?>index.php/library/add_books"><div style="color: #fff;">Add the books</div></a></div>
		<div class="menuitem"><a href="<?php echo base_url();?>index.php/library/addgenre"><div style="color: #fff;">Add Genre</div></a></div>
		<div class="menuitem"><a href="<?php echo base_url();?>index.php/library/addauthor"><div style="color: #fff;">Add author</div></a></div>
		<div class="menuitem"><a href="<?php echo base_url();?>index.php/library/logout"><div style="color: #fff;">logout</div></a></div>
		<br>	<br>	<br>
  </div>


  <div class="main">
	<div style="color: #fff ;font-size: 2vw; " >
	  <h2>contents</h2>
<p>our library content to books,e-books,DVD,CD and Some books have multiple editions.and Some books have more
than one author. Some books have more than one genre..</p>
</div>







</body>
</html>

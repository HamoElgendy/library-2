<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<style media="screen">
	body{
		background: url('https://www.bookprintingcompany.com.au/images/book_sizes.jpg') no-repeat center center fixed;
		-webkit-background-size: cover;
		-moz-background-size: cover;
		-o-background-size: cover;
		background-size: cover;
	}
	</style>
	<title>the library</title>
  <style>
  input[type=text] {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      box-sizing: border-box;
  }
  input[type=text], input[type=password] {
    width: 50%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

  .registerbtn {
      background-color: #2980B9;
      color: white;
      padding: 16px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 10%;
      opacity: 0.9;
  }

  .registerbtn:hover {
      opacity: 15;
  }



  </style>

</head>
<body>
<div><h1>Register Now</h1></div>

<?php
if(isset($result))
{
	echo "Register done";
}
else {

echo '<form name="register" action="'.base_url().'index.php/library/register" onesubmit="return validateForm()" method="post">
  <label for="firstname"><b>First Name</b></label>
  <input type="text" placeholder="Enter First Name" id="fname" name="firstname"required >

	<br><label for="lastname"><b>Last Name</b></label>
  <input type="text" placeholder="Enter last Name" id="lname" name="lastname"required ><br>

  <label for="email"><b>Email</b></label>
  <input type="text" placeholder="Enter Email" name="email" required><br>

  <label for="username"><b>username</b></label>
  <input type="text" placeholder="Enter username" name="username" required><br>

  <label for="password"><b> Password</b></label>
  <input type="password" placeholder="Enter Password" name="password" required><br>



  <input type="radio" name="gender" value="male" > Male<br>
  <input type="radio" name="gender" value="female"> Female<br>';
 echo '</select>
  <button type="submit" class="registerbtn">Register</button>
	</form>';
}
 ?>

 <div class="container login">
<h4><p>Already have an account? <a href="<?php echo base_url();?>index.php/library">login</a></p></h4>
 </div>




</body>
</html>

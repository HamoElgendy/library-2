<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>the library</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>style.css">	<meta charset="utf-8">
<style media="screen">
body{
	background: url('https://www.bookprintingcompany.com.au/images/book_sizes.jpg') no-repeat center center fixed;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size: cover;
	background-size: cover;
}
</style>

<script type="text/javascript">
	   <!--
	      // Form validation code will come here.
	      function validateForm()
	      {

	         if( document.forms["updatebooks"]["bookname"].value == "" )
	         {
	            alert( "Please provide student bookname!" );
	            return false;
	         }

	         if( document.forms["updatebooks"]["ISNBnumber"].value == "" )
	         {
	            alert( "Please provide ISNB Number!" );
	            return false;
	         }
					 if( document.forms["updatebooks"]["publishingdate"].value == "" )
					{
						 alert( "Please provide publishing Date!" );
						 return false;
					}
					if( document.forms["updatebooks"]["multipleeditions"].value == "" )
					{
						 alert( "Please provide multiple Editions!" );
						 return false;
					}
					if( document.forms["updatebooks"]["numberofpages"].value == "" )
					{
						 alert( "Please provide number of pages!" );
						 return false;
					}
					if( document.forms["updatebooks"]["bestofcollections"].value == "" )
					{
						 alert( "Please provide best of collections!" );
						 return false;
					}
					if( document.forms["updatebooks"]["numberofbooks"].value == "" )
					{
						 alert( "Please provide number of books!" );
						 return false;
					}

	      }
	   //-->
	</script>



</head>
<body>
<h1 style=text-align:center>The Update</h1>
<div><h1>Edit books | <?php echo $books->bookname?></h1></div>
<form name="updatebooks" action="<?php echo base_url(); ?>index.php/library/update_book" onsubmit="return validateForm()" method="post">
 book name: <input type="text" name="bookname" value="<?php echo $books->bookname?>"required><br>
ISNB Number: <input type="text" name="ISNBnumber" value="<?php echo $books->ISNBnumber?>"required><br>
 Publishing Date: <input type="text" name="publishingdate" value="<?php echo $books->publishingdate?>"required><br>
 multiple Editions: <input type="text" name="edithionnumber" value="<?php echo $books->edithionnumber?>"required><br>
 printsdate : <input type="date" name="printsdate" value="<?php echo $books->printsdate?>"required><br>

 Number of pages: <input type="text" name="numberofpages" value="<?php echo $books->numberofpages?>"required><br>
 Best of collections: <input type="text" name="bestofcollections" value="<?php echo $books->bestofcollections?>"required><br>
 Number of books: <input type="text" name="numberofbooks" value="<?php echo $books->numberofbooks?>"required><br>

<?php
/*echo '</select>';*/
  echo "<br>Authors</br>";

		 foreach ($authorlist as $author)
		 {
		  $isthere = 0;
			 foreach($books_has_author as $selected)
		 {
			 if($author->idauthor == $selected->author_idauthor)
			 {
				 $isthere = 1;
						 break;
			 }
		 }
	 if($isthere == 1)
	  {
	      echo '<input checked type="checkbox" name="author[]" value="'.$author->idauthor.'"> '.$author->authorname.'<br>';
			 }
		 else
		 {
			 echo '<input type="checkbox" name="author[]" value="'.$author->idauthor.'"> '.$author->authorname.'<br>';
		 }
	 }

	 echo '<br> genre <br>';

	 		 foreach ($genrelist as $genre)
	 		 {
	 		  $isthere = 0;
	 			 foreach($books_has_genre as $selected)
	 		 {
	 			 if($genre->genreid == $selected->genre_genreid)
	 			 {
	 				 $isthere = 1;
	 						 break;
	 			 }
	 		 }
	 	 if($isthere == 1)
	 	  {
	 	      echo '<input checked type="checkbox" name="genre[]" value="'.$genre->genreid.'"> '.$genre->genrename.'<br>';
	 			 }
	 		 else
	 		 {
	 			 echo '<input type="checkbox" name="genre[]" value="'.$genre->genreid.'"> '.$genre->genrename.'<br>';
	 		 }
	 	 }
		 echo '<br> type <br>';

				foreach ($typelist as $type)
				{
				 $isthere = 0;
					foreach($books_has_type as $selected)
				{
					if($type->idtype == $selected->type_idtype)
					{
						$isthere = 1;
								break;
					}
				}
			if($isthere == 1)
			 {
					 echo '<input checked type="checkbox" name="type[]" value="'.$type->idtype.'"> '.$type->typename.'<br>';
					}
				else
				{
					echo '<input type="checkbox" name="type[]" value="'.$type->idtype.'"> '.$type->typename.'<br>';
				}
			}


		echo'    <input type="hidden" name="idbooks" value="'.$books->idbooks.'">
		<input type="submit" value="Update">
		</form>';

?>


</body>
</html>

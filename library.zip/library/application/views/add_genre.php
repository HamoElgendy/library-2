<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<style media="screen">
  body{
    background: url('https://www.bl.uk/britishlibrary/~/media/bl/global/visit/socialsciences04-s.jpg?crop=1&cropX=10&cropY=93&cropW=1989&cropH=1120&w=1248&h=702&dispW=1248&dispH=702') no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
  }
  </style>
	<title>the library</title>
  <style>
  input[type=text] {
      width: 50%;
      padding: 12px 20px;
      margin: 8px 0;
      box-sizing: border-box;
  }
  input[type=text], {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

  .addbtn {
      background-color: #2980B9;
      color: white;
      padding: 16px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 10%;
      opacity: 0.9;
  }

  .addbtn:hover {
      opacity: 1;
  }



  </style>

</head>
<body>
<div><h1>Add genre</h1></div>
<?php
if(isset($result))
{
	echo "genre added";
}
else {

echo '<form name="addgenre" action="'.base_url().'index.php/library/addgenre" onesubmit="return validateForm()" method="post">
  <label for="genrename"><b>Genre Name</b></label>
  <input type="text" placeholder="Enter Genre Name" id="gnerename" name="genrename">';
	echo '</select>
  <br><button type="submit" class="addbtn">Add</button><br>
 	</form>';

}
?>






</body>
</html>

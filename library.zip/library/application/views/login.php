<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>the library</title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
	<style media="screen">
	body{
		background: url('https://abjjadst.blob.core.windows.net/pub/8727bac4-b6cf-44c5-90b9-aa583ba5cc23.jpg') no-repeat center center fixed;
		-webkit-background-size: cover;
		-moz-background-size: cover;
		-o-background-size: cover;
		background-size: cover;
	}
	</style>
	<script type="text/javascript">
	   <!--
	      // Form validation code will come here.
	      function validateForm()
	      {

	         if( document.forms["login"]["username"].value == "" )
	         {
	            alert( "enter username" );
	            return false;
	         }

	         if( document.forms["login"]["password"].value == "" )
	         {
	            alert( "enter password" );
	            return false;
	         }


	      }
	   //-->
	</script>

  <style>
  body {font-family: Arial, Helvetica, sans-serif;}


  input[type=text], input[type=password] {
      width: 50%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
  }

  button {
      background-color: #008080;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      cursor: pointer;
      width: 50%;
  }

  button:hover {
      opacity: 180;
  }

  .cancelbtn {
      width: auto;
      padding: 10px 18px;
      background-color: #f43536;
  }


  </style>
</head>
<body>
<div><h1>welcome to the library</h1></div>

<h2>login</h2>
<div class ="row" >
<div class= "col-md-8 offset-md-2">
  <div class="container">
		<form name="login" action="<?php echo base_url(); ?>index.php/library/login" onsubmit="return validateForm()" method="post">

      <label for="user"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="username" required><br>

      <label for="password"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required ><br>

      <button type="submit">Login</button>
		</form>

      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>
	</div>
</div>



</form>


</body>
</html>

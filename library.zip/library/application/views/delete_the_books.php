<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>the library</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
			table, th, td {
	      border: 1px solid black;
	      border-collapse: collapse;
				padding: 10px
	  }
		.btn {
	    background-color: DodgerBlue;
	    border: 1px solid white;
	    color: white;
	    padding: 5px 15px;
	    font-size: 16px;
	    cursor: pointer;
			float: right;
	}

	/* Darker background on mouse-over */
	.btn:hover {
	    background-color: RoyalBlue;
	}
	</style>
</head>
<body>
<h1 style="text-align:center">Delete</h1>
</form>
<br><table style="width:100%">
<tr>
<th>BookID</th>
<th>BookName</th>
<th>ISBN number</th>
<th>authors</th>
<th>genre</th>
<th>publishing date</th>
<th> Add/delete</th>

</tr>
<tr>
<td>1</td>
<td>Smith</td>
<td>5035164</td>
<td>Jill</td>
<td>Adventure</td>
<td>5/5/2011</td>
<td><button class="btn"><i class="fa fa-trash"></i></button></td>
</tr>
<tr>
<td>2</td>
<td>Jackson</td>
<td>94321654</td>
<td>Eve</td>
<td>Comedy</td>
<td>25/8/2009</td>
<td><button class="btn"><i class="fa fa-trash"></i></button></td>
</tr>
<tr>
<td>3</td>
<td>Doe</td>
<td>8068765</td>
<td>John</td>
<td>Action</td>
<td>30/6/2001</td>
<td><button class="btn"><i class="fa fa-trash"></i></button></td>
</tr>
</table></br>






</body>
</html>

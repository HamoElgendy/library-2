<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class library extends CI_Controller {
	/**
	 * constructer for library controller. we load the models here
	 */
	public function __construct() {
		parent::__construct();

		$this->load->model('login_model');
		$this->load->model('register_model');
		$this->load->model('genre_model');
		$this->load->model('author_model');
		$this->load->model('search_model');
		$this->load->model('showbooks_model');
		$this->load->model('addbooks_model');
		$this->load->helper('url');
	}
	/**
	 * Index loads the defalut view when you go to http://localhost:/library/
	 * @return null no return expcted
	 */
	public function index()
	{
		$this->load->view('login');
	}
	/**
	 * action to the login form in http://localhost:/library/
	 * here we check if we have a correct username and password.
	 * if we do, we create a session with keys isuserloggedin & userrole and redicrect to http://localhost:/library/index.php/library
	 * if not, we disply a "wrong username and password message"
	 * @return null no return expcted
	 */
	public function login()
{
	$result = $this->login_model->loginpass($this->input->post("username"),$this->input->post("password"));
	//if the result is not zero (if there is a record with the inputted username and password)
	if($result!=0)
	{
			//create session, to make sure a user can't access any page without logging in
		$this->session->set_userdata('isuserloggedin', 'true');
			//go to the main page
		redirect('/library/mainpage');
	}
	else
	{
			//disply an error to the user
		echo "wrong username or password";
	}
}
/**
 * mainpage loads http://localhost:/library/index.php/library/mainpage
 * called if login is Successful.
 * @return null no return expcted
 */
public function mainpage()
{
	$this->load->view('hi_everyone');
}
public function logout()
	{
		$this->session->unset_userdata('isuserloggedin');

		redirect('/library');
	}
	/**
	 * register is called when you go to url http://localhost:/library/index.php/library/register
	 * it calls register_model.()
	 * @return null no return expcted
	 */
	public function register()
  {
		if($this->input->post('firstname')||$this->input->post('email')
		||$this->input->post('lastname')||$this->input->post('password')||$this->input->post('username'))
	{
$result =$this->register_model->register();
$data = array();
$data['result'] = $result;
$this->load->view('register',$data);

}
else {
	$this->load->view('register');
	}

	}
	/**
	 * add_books is called when you go to this url http://localhost/library/index.php/library/addgenre
	 * to load this view add_genre from the Database
	 * we use genre_model to get addgenre
	 */
	public function addgenre()
{
if ($this->input->post("genreid") ||$this->input->post("genrename"))
{
	$result = $this->genre_model->addgenre();
	$data = array();
	$data{'result'} = $result;
	$this->load->view('add_genre',$data);
}
	else
	{
			$this->load->view('add_genre');
	}
	}
	/**
	 * add_books is called when you go to this url http://localhost/library/index.php/library/addauthor
	 * to load this view add_author from the Database
	 * we use author_model to get addauthor
	 */
	public function addauthor()
{
if ($this->input->post("idauthor") ||$this->input->post("authorname"))
{
	$result = $this->author_model->addauthor();
	$data = array();
	$data{'result'} = $result;
	$this->load->view('add_author',$data);
}
	else
	{
			$this->load->view('add_author');
	}
}
		public function thesearch()
	{
		//if the form was submitted and the book name feild was posted
		if($this->input->post("bookname"))
		{
			// call student_model.searchbookByName(bookName) to get search results
			$result = $this->search_model->searchbookByName($this->input->post("bookname"));

			//create an empty array called data
			$data = array();

			//add the results from the model which are stored in $result to data and give it key "books"
			//we'll use this key to access the data in the view
			$data['books'] = $result;

			//load view search_the_books.php and pass to it the array data
			$this->load->view('search_the_books',$data);
		}
		else
		{
			//load view search_the_books.php and no data passed
			$this->load->view('search_the_books');
		}

	}
	public function showallbooks()
	{
		//call showbooks_model.get_all_books() to get all books
		$all_books = $this->showbooks_model->get_all_books();
		//create an empty array called data
    $data = array();
		//add the results from the model which are stored in $all_books to data and give it key "books"
		//we'll use this key to access the data in the view
    $data['books'] = $all_books;
		//load view show_the_books.php and pass to it the array data
		$this->load->view('show_the_books',$data);
	}
	/**
	 * add_books is called when you go to this url http://localhost/library/index.php/library/add_books
	 * to load this view we need to get author and get genre and get type from the Database
	 * we use addbooks_model.getauthor() & addbooks_model.getgenre() &addbooks_model.gettype to get the lists
	 */
	public function add_books()
	{
		$result = $this->addbooks_model->getauthor();
		$data = array();
		$data['authorlist'] = $result;
		$result = $this->addbooks_model->getgenre();
		$data['genrelist'] = $result;
		$result = $this->addbooks_model->gettype();
		$data['typelist'] = $result;
		$this->load->view('add_the_books',$data);
	}
	/**
	 * add_books_result is the action from the from in http://localhost:/library/index.php/library/add_books
	 * we call student_model.addStudent() function to insert the new student to the database
	 */
	public function addbooksresult()
	{
			$this->addbooks_model->theaddbooks();
			$this->load->view('add_books_result');
	}
	/**
	 * editbooks is called when you click on the edit button in show the books page. the link to show this function is http://localhost/library/index.php/library/editbooks/1
	 * in the link editbooks/1 .. editbooks is the function & 1 is the id of the user we'll be editing.
	 * in editUser we prepare all the required data to autofill the form with the current user details
	 * @param  Integer $id user id we wish to edit
	 * @return null     no return expected
	 */
	public function editbooks($id)
	{
		$result = $this->addbooks_model->getauthor();
		$data = array();
		$data['authorlist'] = $result;
		$result = $this->addbooks_model->getgenre();
		$data['genrelist'] = $result;
		$result = $this->addbooks_model->gettype();
		$data['typelist'] = $result;
		$result = $this->addbooks_model->getbooksDetailsbyID($id);
		$data['books'] = array_pop($result);
		$result = $this->addbooks_model->getbooks_has_authorbyID($id);
		$data['books_has_author'] = $result;
		$result = $this->addbooks_model->getbooks_has_genrebyID($id);
		$data['books_has_genre'] = $result;
		$result = $this->addbooks_model->getbooks_has_typebyID($id);
		$data['books_has_type'] = $result;
		$this->load->view('update_the_books',$data);
	}
	/**
	 * the action from the form in  http://localhost/library/index.php/library/editbooks/1
	 * updatebook will take the data from the form and updates the books based on their ID
	 * @return null no return expected
	 */
	public function update_book()
	{
		if($this->input->post("bookname") || $this->input->post("ISNBnumber")
		|| $this->input->post("publishingdate") || $this->input->post("edithionnumber")  || $this->input->post("printsdate")
		|| $this->input->post("numberofpages")|| $this->input->post("bestofcollections")
		|| $this->input->post("numberofbooks")|| $this->input->post("author_idauthor")
		|| $this->input->post("genre_genreid")|| $this->input->post("type_idtype")
		|| $this->input->post("idbooks"))
{

			$result = $this->addbooks_model->updatebook();
			$data = array();
			$data['result'] = $result;
			$this->load->view('update_books_result',$data);
		}
	}

	public function delete_book($id)
	{
		$result = $this->addbooks_model->thedelete($id);
			echo "doen deleted";
	}



}

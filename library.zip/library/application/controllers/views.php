<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class views extends CI_Controller {

	public function __construct() {
		parent::__construct();


	}
  public function theadd ()
  {
    $this->load->view('add_the_books');
  }
  public function thedelete()
  {
    $this->load->view('delete_the _books');
  }
  public function updatebooks()
  {
    $this->load->view('update_the_books');
  }
  public function thesearch()
  {
    $this->load->view('search_the_books');
  }
  public function showthebooks()
  {
    $this->load->view('show_the_books');
  }
  public function myregister()
  {
    $this->load->view('register');
  }

  }
